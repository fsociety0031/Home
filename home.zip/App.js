import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Modal,
  TouchableHighlight,
  Button,
  Image,
  Platform,
  TouchableOpacity,
  Alert
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons'
import Constants from 'expo-constants';
import * as LocalAuthentication from 'expo-local-authentication';
import { WebView } from 'react-native-webview';

export default class App extends React.Component {
  state = {
    authenticated: false,
    modalVisible: false,
    failedCount: 0,
  };

  setModalVisible(visible) {
    this.setState({ modalVisible: visible });
  }

  clearState = () => {
    this.setState({ authenticated: false, failedCount: 0 });
  };

  scanFingerPrint = async () => {
    try {
      let results = await LocalAuthentication.authenticateAsync(
        {promptMessage: 'Acesse sua conta utilizando o leitor de impressão digital do seu aparelho.', cancelLabel: 'Sua ação foi cancelada.'});
      if (results.success) {
        this.setState({
          modalVisible: false,
          authenticated: true,
          failedCount: 0,
        });
      } else {
        this.setState({
          failedCount: this.state.failedCount + 1,
        });
      }
    } catch (e) {
      console.log(e);
    }
  };

  render() {
    return (
      <View
        style={[
          styles.container,
          this.state.modalVisible
            ? { backgroundColor: '#b7b7b7' }
            : { backgroundColor: 'white' },
        ]}>
        <Image source={require('./assets/shutterstock_533153143.jpg')} style={{
      width: 320,
      height: 500,
      left: 0,
      top: 0,
      position: 'absolute',
      
  }} />

      <Text style={{
        position: 'absolute',
        left: 27,
        top: 150,
        fontStyle: 'normal',
        fontWeight: '100',
        fontSize: 48,
        lineHeight: 56,
        textAlign: 'center',
        letterSpacing: 0.075,
        color: '#FFFFFF'
        }} >SERVICE ROOM</Text>

        <TouchableOpacity
          style={{
            width: 50,
            height: 50,
            backgroundColor: '#061019',
            borderRadius: 25,
            justifyContent: 'center',
            alignItems: 'center',
            marginLeft: 130,
            bottom: 20
          }}
          
          onPress={() => {
            this.clearState();
            if (Platform.OS === 'android') {
              this.setModalVisible(!this.state.modalVisible);
            } else {
              this.scanFingerPrint();
            }
          }}
        >
    <MaterialIcons name={this.state.authenticated
              ? 'arrow-back'
              : 'fingerprint'} size={20} color="#FFF"/>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => { Alert.alert(
  'Ocorreu um erro',
  'Seu e-mail ou senha não confere!',
  [
    {text: 'OK', onPress: () => console.log('OK Pressed')},
  ],
  {cancelable: true},
);   }} 
    style={{
    width: 147,
    height: 47,
    borderWidth: 2,
    borderColor: '#2A3E73',
    backgroundColor: '#fff',
    borderRadius: 3,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 0,
    top: 245
  }}><Text style={{fontWeight: 900}}>LOGIN</Text></TouchableOpacity>

<TouchableOpacity onPress={() => { alert('REGISTAR PRESSIONADO') }} style={{
    width: 147,
    height: 47,
    borderWidth: 2,
    borderColor: '#2A3E73',
    backgroundColor: '#2A3E73',
    borderRadius: 3,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 150,
    top: 197
  }}><Text style={{ fontWeight: 900, color: '#fff' }}>REGISTRAR</Text></TouchableOpacity>

        {this.state.authenticated && (
          <WebView  style={{ flex: 1 }} source={{ uri: `https://github.com/fsociety0031` }} />
        )}

        <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVisible}
          onShow={this.scanFingerPrint}>
          <View style={styles.modal}>
            <View style={styles.innerContainer}>
              <Text>Entre com a impressão digital</Text>
              <Image
                style={{ width: 128, height: 128 }}
                source={require('./assets/fingerprint.png')}
              />
              {this.state.failedCount > 0 && (
                <Text style={{ color: 'red', fontSize: 14 }}>
                  Falha ao autenticar, pressione cancelar para tentar novamente.
                </Text>
              )}
              <TouchableHighlight
                onPress={async () => {
                  LocalAuthentication.cancelAuthenticate();
                  this.setModalVisible(!this.state.modalVisible);
                }}>
                <Text style={{ color: 'red', fontSize: 20, paddingBottom: 10 }}>Cancelar</Text>
              </TouchableHighlight>
            </View>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignContent: 'center',
    paddingTop: Constants.statusBarHeight,
    padding: 8,
  },
  modal: {
    flex: 1,
    backgroundColor: '#E5E5E5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  innerContainer: {
    marginTop: '30%',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    alignSelf: 'center',
    fontSize: 22,
    paddingTop: 20,
  },
});
